import{U as f}from"./index-MnGl3J6L.js";export{f as default};

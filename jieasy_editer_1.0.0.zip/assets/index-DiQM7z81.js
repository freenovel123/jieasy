import{g as e,o as c,c as n}from"./index-BtloBOCn.js";const o={};function t(r,s){return c(),n("div",null,"document")}const _=e(o,[["render",t]]);export{_ as default};

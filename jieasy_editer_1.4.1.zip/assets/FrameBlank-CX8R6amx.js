import{f as e,_ as n,c as a,o}from"./index-DQ6KTaqe.js";const t=e({name:"FrameBlank"});function r(c,s,p,_,f,m){return o(),a("div")}const i=n(t,[["render",r]]);export{i as default};

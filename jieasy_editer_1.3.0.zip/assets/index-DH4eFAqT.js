import{_ as e,o as c,c as n}from"./index--TtAS5k8.js";const o={};function t(r,s){return c(),n("div",null,"document")}const a=e(o,[["render",t]]);export{a as default};

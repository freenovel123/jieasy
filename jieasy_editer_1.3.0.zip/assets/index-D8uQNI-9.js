import{Q as f}from"./index--TtAS5k8.js";export{f as default};

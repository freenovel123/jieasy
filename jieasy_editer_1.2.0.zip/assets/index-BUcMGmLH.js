import{Q as f}from"./index-tdqupW6R.js";export{f as default};

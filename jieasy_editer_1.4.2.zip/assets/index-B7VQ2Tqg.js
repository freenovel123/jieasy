import{U as f}from"./index-B8kRM21t.js";export{f as default};

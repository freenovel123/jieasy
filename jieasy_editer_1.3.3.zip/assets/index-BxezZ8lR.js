import{U as f}from"./index-CnqRjey8.js";export{f as default};

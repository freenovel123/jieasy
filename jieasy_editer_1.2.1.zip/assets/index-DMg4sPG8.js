import{Q as f}from"./index-CgOOQVTy.js";export{f as default};

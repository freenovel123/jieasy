import{d as e,g as n,c as a,o}from"./index-2jiUCer3.js";const t=e({name:"FrameBlank"});function r(c,s,p,m,_,d){return o(),a("div")}const i=n(t,[["render",r]]);export{i as default};
